var lolz = "";
var lolz1 = "";
var lolz2 = "";
var name_v = "1";
var pr_v = "1";

var otkuda = "";
var kuda = "";
var kogda = "";
var obratno = "";
var skok = "";

var openOFF = false;
var openOFF1 = false;
const loginText = document.querySelector(".title-text .login");
const loginForm = document.querySelector("form.login");
const loginBtn = document.querySelector("label.login");
const signupBtn = document.querySelector("label.signup");
const signupLink = document.querySelector("form .signup-link a");
const showDialogBtn = document.querySelector('#show-dialog-btn');
const showDialogBtn1 = document.querySelector('#show-dialog-btn1');
const showDialogBtn2 = document.querySelector('#show-dialog-btn2');
const showDialogBtn3 = document.querySelector('#show-dialog-btn3');
const myDialog = document.querySelector('#my-dialog');
const myDialog1 = document.querySelector('#my-dialog1');
const myDialog2 = document.querySelector('#my-dialog2');
const myDialog3 = document.querySelector('#my-dialog3');
const closeDialogBtn = document.querySelector('#close-dialog-btn');
const closeDialogBtn1 = document.querySelector('#close-dialog-btn1');
const closeDialogBtn2 = document.querySelector('#close-dialog-btn2');
const closeDialogBtn3 = document.querySelector('#close-dialog-btn3');
showDialogBtn.addEventListener('click', () => {
  if (openOFF) {
    document.getElementById('privel').innerHTML = name_v;
    myDialog1.showModal();
  }
  else {
    myDialog.showModal();
  }
});
closeDialogBtn.addEventListener('click', () => {
  document.getElementById('pop').innerHTML = "";
  myDialog.close();
});
showDialogBtn1.addEventListener('click', () => {
  if (openOFF) {
    document.getElementById('privel').innerHTML = name_v;
    myDialog1.showModal();
  }
});
closeDialogBtn1.addEventListener('click', () => {
  myDialog1.close();
});
showDialogBtn2.addEventListener('click', () => {
  if (openOFF) {
    myDialog2.showModal();
  }
  else {
    openOFF1 = true;
    myDialog.showModal();
  }
});
closeDialogBtn2.addEventListener('click', () => {
  myDialog2.close();
});

showDialogBtn3.addEventListener('click', () => {
  myDialog3.showModal();
});
closeDialogBtn3.addEventListener('click', () => {
  myDialog3.close();
});




signupBtn.onclick = () => {
  document.getElementById('pop').innerHTML = "";
  loginForm.style.marginLeft = "-50%";
  loginText.style.marginLeft = "-50%";
};
loginBtn.onclick = () => {
  document.getElementById('pop').innerHTML = "";
  loginForm.style.marginLeft = "0%";
  loginText.style.marginLeft = "0%";
};
signupLink.onclick = () => {
  signupBtn.click();
  return false;
};

function kk_reg() {
  lolz = document.getElementById('name_reg');
  lolz1 = document.getElementById('pr_reg');
  lolz2 = document.getElementById('pr_prov_reg');
  name_v = lolz.value;
  pr_v = lolz1.value;
  if (lolz1.value == lolz2.value && name_v != "" && pr_v != "") {
    document.getElementById('pop').innerHTML = "Учетная запись создана!";
  }
}

function kk() {
  lolz = document.getElementById('name_vxod');
  lolz1 = document.getElementById('pr_vxod');
  if (name_v == lolz.value && pr_v == lolz1.value && name_v != "" && pr_v != "") {
    document.getElementById('show-dialog-btn').innerHTML = lolz.value;
    openOFF = true;
    myDialog.close();
    document.getElementById('privel').innerHTML = name_v;
    if (openOFF1) {
      myDialog2.showModal();
    }
    else {
      myDialog1.showModal();
    }
    openOFF1 = false;
  }
}

function open_reg() {
  if (document.getElementById('pop').innerHTML == name_v) {
    document.getElementById('privel').innerHTML = name_v;
  }
  myDialog1.showModal();
}

function ping() {
  otkuda = document.getElementById('otkuda');
  kuda = document.getElementById('kuda');
  kogda = document.getElementById('kogda');
  obratno = document.getElementById('obratno');
  skok = document.getElementById('check');
  if (otkuda.value != "" && kuda.value != "" && kogda.value != "" && obratno != " "&& skok.value != "") {
    myDialog2.close();
    document.getElementById('otkuda_r').innerHTML = "Откуда: " + otkuda.value;
    document.getElementById('kuda_r').innerHTML = "Куда: " + kuda.value;
    document.getElementById('kogda_r').innerHTML = "Когда: " + kogda.value;
    document.getElementById('obratno_r').innerHTML = "Обратно: " + obratno.value;
    document.getElementById('skok_r').innerHTML = "Колич. билетов: " + skok.value;
  }
}

document.getElementById('check').onkeypress = function (e) {
  return false;
}

function handleImageUpload() {

  var image = document.getElementById("upload").files[0];

  var reader = new FileReader();

  reader.onload = function (e) {
    document.getElementById("display-image").src = e.target.result;
    document.getElementById("display-image1").src = e.target.result;
  }

  reader.readAsDataURL(image);

}
/*const fs = require("fs");
const { type } = require("os");

//var name = document.querySelector('#name');
var name = "егор"; //имя
//var pr = document.querySelector('#pr_vxod');
var pr = "1234"; //пороль
var sum = 0;
var sum1 = 0;
var button2 = document.getElementById("addButton2")
button2.onclick = handleButtonClick2;

function multi() {
  fs.readFile("сайт по аренда билетов/js/login.txt", function (error, data) {
    if (err) throw err;
    function splitString(stringToSplit) {
      var arrayOfStrings = stringToSplit.split(" ");
      for (var index = 0; index < arrayOfStrings.length; index++) {
        var fil = data.toString().split(" ")[index];
        if (fil == name) {
          sum++;
          break;
        }
        else {
          sum++;
        }
      }
    }
    alert()
    splitString(data.toString());
  });
  fs.readFile("сайт по аренда билетов/js/pr.txt", function (error, data) {
    if (err) throw err;
    function splitString(stringToSplit) {
      var arrayOfStrings = stringToSplit.split(" ");
      for (var index = 0; index < arrayOfStrings.length; index++) {
        var fil = data.toString().split(" ")[index];
        if (fil == pr) {
          sum1++;
          break;
        }
        else {
          sum1++;
        }
      }
    }
    splitString(data.toString());
    if (sum == sum1 && pr != "" && name != "") {
      console.log(true);
      alert("true");
      document.getElementById('myBtn').innerHTML = 'егор';

    }
    else {
      console.log(false);
      alert("false");
    }
    sum = 0;
    sum1 = 0;
  });
};*/
